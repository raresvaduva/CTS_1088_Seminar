package ro.ase.csie.cts.g1088.testare.exceptii;

public class ExceptieNota extends Exception{
}
