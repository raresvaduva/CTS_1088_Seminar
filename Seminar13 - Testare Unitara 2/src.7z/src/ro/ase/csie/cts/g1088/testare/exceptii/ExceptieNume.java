package ro.ase.csie.cts.g1088.testare.exceptii;

public class ExceptieNume extends Exception{
}
